export const dashboardPage = './dashboard.html';
export const adminLoginPage = "./adminLogin.html";
export const userRegistrationPage = 'userRegistration.html';
export const userLoginPage = './userLogin.html';
export const adminRegistrationPage = './adminRegistration.html';
export const viewProfilePage = './viewProfile.html';
export const editProfilePage = "./editProfile.html";
export const changePasswordPage = "./changePassword.html";